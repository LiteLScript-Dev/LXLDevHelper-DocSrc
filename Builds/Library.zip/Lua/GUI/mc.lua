---mc通用接口
---@class mc 
 mc = {}

---创建表单对象
---@return CustomForm 新创建的空白表单对象
function mc.newCustomForm()
end

---创建表单对象
---@return SimpleForm 新创建的空白表单对象
function mc.newSimpleForm()
end