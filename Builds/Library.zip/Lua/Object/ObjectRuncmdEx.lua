---mc.runcmdEx的返回结果
---@class ObjectRuncmdEx 
---@field success Boolean Boolean
---@field output String String
 ObjectRuncmdEx = {}