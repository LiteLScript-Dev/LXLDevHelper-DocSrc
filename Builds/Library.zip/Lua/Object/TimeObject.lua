---时间对象
---@class TimeObject 
---@field Y Integer Integer
---@field M Integer Integer
---@field D Integer Integer
---@field h Integer Integer
---@field m Integer Integer
---@field s Integer Integer
---@field ms Integer Integer
 TimeObject = {}