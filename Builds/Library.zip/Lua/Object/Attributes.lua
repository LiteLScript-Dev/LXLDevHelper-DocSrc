---Attributes属性
---@class Attributes 
---@field Base Integer Integer
---@field Current Integer Integer
---@field DefaultMax Integer Integer
---@field DefaultMin Integer Integer
---@field Max Integer Integer
---@field Min Integer Integer
---@field Name String String
 Attributes = {}