---历史账单
---@class ObjectTransHistory 
---@field from  
---@field to  
---@field money  
---@field time  
---@field note  
 ObjectTransHistory = {}