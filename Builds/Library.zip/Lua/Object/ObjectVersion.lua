---加载器版本对象
---@class ObjectVersion 
---@field major Integer Integer
---@field minor Integer Integer
---@field revision Integer Integer
---@field isBeta Boolean Boolean
 ObjectVersion = {}