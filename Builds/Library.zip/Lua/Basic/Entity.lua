---
---@class Entity 
 Entity = {}