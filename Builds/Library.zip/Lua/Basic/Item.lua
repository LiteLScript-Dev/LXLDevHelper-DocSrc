---🧰 物品对象 API
在LXL中，使用「物品对象」来操作和获取某一个物品栏物品的相关信息
---@class Item 
 Item = {}

---通过 现有的物品对象 生成一个新的物品对象
---@return Item 生成的新物品对象
function Item:clone()
end