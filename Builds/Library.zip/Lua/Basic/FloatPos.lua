---🎯 坐标对象
多用来表示实体坐标等用无法用整数表示的位置
---@class FloatPos 
---@field x Float Float
---@field y Float Float
---@field z Float Float
---@field dim String String
---@field dimid Integer Integer
 FloatPos = {}