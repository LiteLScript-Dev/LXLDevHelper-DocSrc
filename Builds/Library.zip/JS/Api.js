
/// <reference path="./Basic/Block.js" />
/// <reference path="./Basic/Entity.js" />
/// <reference path="./Basic/FloatPos.js" />
/// <reference path="./Basic/IntPos.js" />
/// <reference path="./Basic/Item.js" />
/// <reference path="./Basic/Player.js" />
/// <reference path="./Global/Global.js" />
/// <reference path="./Helpful/logger.js" />
/// <reference path="./Helpful/lxl.js" />
/// <reference path="./Object/Device.js" />
/// <reference path="./Object/Float.js" />
/// <reference path="./Object/ObjectRuncmdEx.js" />
/// <reference path="./Object/ObjectVersion.js" />
/// <reference path="./Class/mc.js" />