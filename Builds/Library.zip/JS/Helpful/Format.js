/**
 * 格式化代码实用工具
 */ 
class Format {
  
/**
 * 接下来的文字为 黑色 §0
 * @type String
 */ 
 static Black;
/**
 * 接下来的文字为 深蓝色 §1
 * @type String
 */ 
 static DarkBlue;
/**
 * 接下来的文字为 深绿色 §2
 * @type String
 */ 
 static DarkGreen;
/**
 * 接下来的文字为 湖蓝色 §3
 * @type String
 */ 
 static DarkAqua;
/**
 * 接下来的文字为 深红色 §4
 * @type String
 */ 
 static DarkRed;
/**
 * 接下来的文字为 紫色 §5
 * @type String
 */ 
 static DarkPurple;
/**
 * 接下来的文字为 金色 §6
 * @type String
 */ 
 static Gold;
/**
 * 接下来的文字为 灰色 §7
 * @type String
 */ 
 static Gray;
/**
 * 接下来的文字为 深灰色 §8
 * @type String
 */ 
 static DarkGray;
/**
 * 接下来的文字为 蓝色§9
 * @type String
 */ 
 static Blue;
/**
 * 接下来的文字为 浅绿色 §a
 * @type String
 */ 
 static Green;
/**
 * 接下来的文字为 天蓝色 §b
 * @type String
 */ 
 static Aqua;
/**
 * 接下来的文字为 浅红色 §c
 * @type String
 */ 
 static Red;
/**
 * 接下来的文字为 浅紫色 §d
 * @type String
 */ 
 static LightPurple;
/**
 * 接下来的文字为 浅黄色 §e
 * @type String
 */ 
 static Yellow;
/**
 * 接下来的文字为 白色 §f
 * @type String
 */ 
 static White;
/**
 * 接下来的文字为 硬币金色 §g
 * @type String
 */ 
 static MinecoinGold ;
/**
 * 接下来的文字 加粗 §l
 * @type String
 */ 
 static Bold;
/**
 * 接下来的文字 意大利体（俗称斜体）§o
 * @type String
 */ 
 static Italics;
/**
 * 接下来的文字 下划线 §n
 * @type String
 */ 
 static Underline;
/**
 * 接下来的文字 删除线 §m
 * @type String
 */ 
 static StrikeThrough;
/**
 * 接下来的文字 随机闪烁的乱码字符 §k
 * @type String
 */ 
 static Random;
/**
 * 接下来的文字 清除所有格式§r
 * @type String
 */ 
 static Clear;
  
  
  



}
