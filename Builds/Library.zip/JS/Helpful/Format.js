/**
 * 格式化代码实用工具类
 */ 
class Format {
  
/**
 * 接下来的文字为 黑色 §0
 * @type 
 */ 
 static Black;
/**
 * 接下来的文字为 深蓝色 §1
 * @type 
 */ 
 static DarkBlue;
/**
 * 接下来的文字为 深绿色 §2
 * @type 
 */ 
 static DarkGreen;
/**
 * 接下来的文字为 湖蓝色 §3
 * @type 
 */ 
 static DarkAqua;
/**
 * 接下来的文字为 深红色 §4
 * @type 
 */ 
 static DarkRed;
/**
 * 接下来的文字为 紫色 §5
 * @type 
 */ 
 static DarkPurple;
/**
 * 接下来的文字为 金色 §6
 * @type 
 */ 
 static Gold;
/**
 * 接下来的文字为 灰色 §7
 * @type 
 */ 
 static Gray;
/**
 * 接下来的文字为 深灰色 §8
 * @type 
 */ 
 static DarkGray;
/**
 * 接下来的文字为 蓝色§9
 * @type 
 */ 
 static Blue;
/**
 * 接下来的文字为 浅绿色 §a
 * @type 
 */ 
 static Green;
/**
 * 接下来的文字为 天蓝色 §b
 * @type 
 */ 
 static Aqua;
/**
 * 接下来的文字为 浅红色 §c
 * @type 
 */ 
 static Red;
/**
 * 接下来的文字为 浅紫色 §d
 * @type 
 */ 
 static LightPurple;
/**
 * 接下来的文字为 浅黄色 §e
 * @type 
 */ 
 static Yellow;
/**
 * 接下来的文字为 白色 §f
 * @type 
 */ 
 static White;
/**
 * 接下来的文字为 硬币金色 §g
 * @type 
 */ 
 static MinecoinGold ;
/**
 * 接下来的文字 加粗 §l
 * @type 
 */ 
 static Bold;
/**
 * 接下来的文字 意大利体（俗称斜体）§o
 * @type 
 */ 
 static Italics;
/**
 * 接下来的文字 下划线 §n
 * @type 
 */ 
 static Underline;
/**
 * 接下来的文字 删除线 §m
 * @type 
 */ 
 static StrikeThrough;
/**
 * 接下来的文字 随机闪烁的乱码字符 §k
 * @type 
 */ 
 static Random;
/**
 * 接下来的文字 清除所有格式§r
 * @type 
 */ 
 static Clear;
  
  
  



}
