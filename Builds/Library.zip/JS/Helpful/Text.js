/**
 * 格式化代码实用工具
 */ 
class Text {
  
/**
 * 接下来的文字为 黑色 §0
 * @type 
 */ 
 Black;
/**
 * 接下来的文字为 深蓝色 §1
 * @type 
 */ 
 DarkBlue;
/**
 * 接下来的文字为 深绿色 §2
 * @type 
 */ 
 DarkGreen;
/**
 * 接下来的文字为 湖蓝色 §3
 * @type 
 */ 
 DarkAqua;
/**
 * 接下来的文字为 深红色 §4
 * @type 
 */ 
 DarkRed;
/**
 * 接下来的文字为 紫色 §5
 * @type 
 */ 
 DarkPurple;
/**
 * 接下来的文字为 金色 §6
 * @type 
 */ 
 Gold;
/**
 * 接下来的文字为 灰色 §7
 * @type 
 */ 
 Gray;
/**
 * 接下来的文字为 深灰色 §8
 * @type 
 */ 
 DarkGray;
/**
 * 接下来的文字为 蓝色§9
 * @type 
 */ 
 Blue;
/**
 * 接下来的文字为 浅绿色 §a
 * @type 
 */ 
 Green;
/**
 * 接下来的文字为 天蓝色 §b
 * @type 
 */ 
 Aqua;
/**
 * 接下来的文字为 浅红色 §c
 * @type 
 */ 
 Red;
/**
 * 接下来的文字为 浅紫色 §d
 * @type 
 */ 
 LightPurple;
/**
 * 接下来的文字为 浅黄色 §e
 * @type 
 */ 
 Yellow;
/**
 * 接下来的文字为 白色 §f
 * @type 
 */ 
 White;
/**
 * 接下来的文字为 硬币金色 §g
 * @type 
 */ 
 MinecoinGold ;
/**
 * 接下来的文字 加粗 §l
 * @type 
 */ 
 Bold;
/**
 * 接下来的文字 意大利体（俗称斜体）§o
 * @type 
 */ 
 Italics;
/**
 * 接下来的文字 下划线 §n
 * @type 
 */ 
 Underline;
/**
 * 接下来的文字 删除线 §m
 * @type 
 */ 
 StrikeThrough;
/**
 * 接下来的文字 随机闪烁的乱码字符 §k
 * @type 
 */ 
 Random;
/**
 * 接下来的文字 清除所有格式§r
 * @type 
 */ 
 Clear;
  
  
  



}
