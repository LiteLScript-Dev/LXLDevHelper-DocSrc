/**
 * float
 */ 
class Float {
  
  
  
  



}
