/**
 * 二进制数据
 */ 
class ByteBuffer {
  
  
  
  



}
