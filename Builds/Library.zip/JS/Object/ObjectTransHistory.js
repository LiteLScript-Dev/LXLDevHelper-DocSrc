/**
 * 历史账单
 */ 
class ObjectTransHistory {
  
/**
 * 
 * @type 
 */ 
 from;
/**
 * 
 * @type 
 */ 
 to;
/**
 * 
 * @type 
 */ 
 money;
/**
 * 
 * @type 
 */ 
 time;
/**
 * 
 * @type 
 */ 
 note;
  
  
  



}
