/**
 * Attributes属性
 */ 
class Attributes {
  
/**
 * 
 * @type Integer
 */ 
 Base;
/**
 * 
 * @type Integer
 */ 
 Current;
/**
 * 
 * @type Integer
 */ 
 DefaultMax;
/**
 * 
 * @type Integer
 */ 
 DefaultMin;
/**
 * 
 * @type Integer
 */ 
 Max;
/**
 * 
 * @type Integer
 */ 
 Min;
/**
 * 
 * @type String
 */ 
 Name;
  
  
  



}
