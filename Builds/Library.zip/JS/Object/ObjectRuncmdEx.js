/**
 * mc.runcmdEx的返回结果
 */ 
class ObjectRuncmdEx {
  
/**
 * 是否执行成功
 * @type Boolean
 */ 
 static success;
/**
 * BDS执行命令后的输出结果
 * @type String
 */ 
 static output;
  
  
  



}
