/**
 * mc.runcmdEx的返回结果
 */ 
class ObjectRuncmdEx {
  
/**
 * 是否执行成功
 * @type Boolean
 */ 
 success;
/**
 * BDS执行命令后的输出结果
 * @type String
 */ 
 output;
  
  
  



}
