/**
 * 时间对象
 */ 
class TimeObject {
  
/**
 * 年份数值（4位）
 * @type Integer
 */ 
 Y;
/**
 * 月份数值
 * @type Integer
 */ 
 M;
/**
 * 天数数值
 * @type Integer
 */ 
 D;
/**
 * 小时数值（24小时制）
 * @type Integer
 */ 
 h;
/**
 * 分钟数值
 * @type Integer
 */ 
 m;
/**
 * 秒数值
 * @type Integer
 */ 
 s;
/**
 * 毫秒数值
 * @type Integer
 */ 
 ms;
  
  
  



}
