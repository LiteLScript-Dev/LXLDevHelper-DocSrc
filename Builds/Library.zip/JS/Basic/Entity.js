/**
 * 
 */ 
class Entity {
  
  
  
  



}
